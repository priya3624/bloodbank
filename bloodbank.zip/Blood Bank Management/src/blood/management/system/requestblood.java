
package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class requestblood extends JFrame implements ActionListener
{
    JTextField  tfpatient,tfdoctor,tfunits,tfnumber,tfloation;
    JComboBox cblood;
    JButton submit,back;
            
    requestblood(){
        
        setSize(900,600);
        setLocation(300,100);
        setLayout(null);
        
        JLabel heading = new JLabel("BLOOD REQUEST FORM");
        heading.setBounds(250, 30, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 30));
        add(heading);
        
        JLabel pname = new JLabel("Patient Name:- ");
        pname.setBounds(70, 150, 150, 30);
        pname.setFont(new Font("serif", Font.BOLD, 20));
        add(pname);
        
        tfpatient = new JTextField();
        tfpatient.setBounds(220, 150, 180, 30);
        add(tfpatient);
        
        JLabel dname = new JLabel("Doctor Name:- ");
        dname.setBounds(70, 200, 150, 30);
        dname.setFont(new Font("serif", Font.BOLD, 20));
        add(dname);
        
        tfdoctor = new JTextField();
        tfdoctor.setBounds(220, 200, 180, 30);
        add(tfdoctor);
        
        JLabel lblcourse = new JLabel("Blood Group:- ");
        lblcourse.setBounds(70, 250, 200, 30);
        lblcourse.setFont(new Font("serif", Font.BOLD, 20));
        add(lblcourse);
        
        String blood[] = {"A+", "A-", "B+", "B-", "AB+","AB-", "O+", "O-"};
        cblood = new JComboBox(blood);
        cblood.setBounds(220, 250, 180, 30);
        cblood.setBackground(Color.white);
        add(cblood);
        
        JLabel units = new JLabel("Blood Units:- ");
        units.setBounds(70, 300, 150, 30);
        units.setFont(new Font("serif", Font.BOLD, 20));
        add(units);
        
        tfunits = new JTextField();
        tfunits.setBounds(220, 300, 180, 30);
        add(tfunits);
        
        JLabel location = new JLabel("Location:- ");
        location.setBounds(70, 350, 150, 30);
        location.setFont(new Font("serif", Font.BOLD, 20));
        add(location);
        
        tfloation = new JTextField();
        tfloation.setBounds(220, 350, 180, 30);
        add(tfloation);
        
        JLabel phone = new JLabel("Phone Number:- ");
        phone.setBounds(70, 400, 150, 30);
        phone.setFont(new Font("serif", Font.BOLD, 20));
        add(phone);
        
        tfnumber = new JTextField();
        tfnumber.setBounds(220, 400, 180, 30);
        add(tfnumber);
        
        submit = new JButton("Submit");
        submit.setBounds(50, 480, 110, 30);
        submit.setBackground(Color.white);
        submit.setForeground(Color.black);
        submit.addActionListener(this);
        submit.setFont(new Font("Tahome", Font.BOLD, 15));
        add(submit);
        
        back = new JButton("Back");
        back.setBounds(250, 480, 110, 30);
        back.setBackground(Color.white);
        back.setForeground(Color.black);
        back.addActionListener(this);
        back.setFont(new Font("Tahome", Font.BOLD, 15));
        add(back);
       
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/aaad.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(950, 650, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 950, 650);
        add(image);
        
        setVisible(true); 
     
    }
    public void actionPerformed(ActionEvent ae) 
    {
        if (ae.getSource() == submit) {
            
            String pname = tfpatient.getText();
             String dname = tfdoctor.getText();
             String blood = (String) cblood.getSelectedItem();
            String units = tfunits.getText();
             String location = tfloation.getText();
             String phone = tfnumber.getText();
             
             if (tfpatient.getText().trim().isEmpty() || tfdoctor.getText().trim().isEmpty() || tfunits.getText().trim().isEmpty() || tfloation.getText().trim().isEmpty() || tfnumber.getText().trim().isEmpty() )
             {
                 JOptionPane.showMessageDialog(null, "Please fill in all the details.");
                 } else if (!isValidName(tfpatient.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid Full Name.");
             } else if (!isValidName(tfdoctor.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid Doctor Name.");
             } else if (!isValidNumber(tfunits.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid blood units");
             } else if (!isValidName(tfloation.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid location.");
             } else if (!isValidPhoneNumber(tfnumber.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter Phone Number.");
             }
             else {
                 if (!isValidName(pname)) {
                    JOptionPane.showMessageDialog(null, "The patient name is not valid");
                } else if (!isValidName(dname)) {
                    JOptionPane.showMessageDialog(null, "The doctor name  is not valid");
                } else if (!isValidNumber(units)) {
                     JOptionPane.showMessageDialog(null, "The units is not valid");
            } else if (!isValidName(location)) {
                     JOptionPane.showMessageDialog(null, "The loaction is not valid");
            } else if (!isValidPhoneNumber(phone)) {
                     JOptionPane.showMessageDialog(null, "The Phone Number is not valid");
            } else {
                    
                }
             try {
                 
                 String query = "Insert into request values('"+pname+"','"+dname+"','"+blood+"','"+units+"','"+location+"','"+phone+"')";
                 
                  Conn c = new Conn();
                  c.s.executeUpdate(query);
                  
                  JOptionPane.showMessageDialog(null, "Account Created Successfully");
                  
                  setVisible(false);
           //       new Login();
             } catch(Exception e){
                 e.printStackTrace();
             }
            
             } } else if(ae.getSource() == back){
             setVisible(false);
        }
    }
        
        private boolean isValidPhoneNumber(String phone)
        {
        String phoneRegex = "^[0-9]{10}$";
        return phone.matches(phoneRegex);
       }

    private boolean isValidName(String name) {
        String NAME_REGEX = "^[a-zA-Z\\s-]+$";
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
    private boolean isValidNumber(String number) {
        String NUMBER_REGEX = "^\\d+$"; // Regular expression to match only numbers
        Pattern pattern = Pattern.compile(NUMBER_REGEX);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

    
    public static void main(String[] args) {
        new requestblood();
    }
}
