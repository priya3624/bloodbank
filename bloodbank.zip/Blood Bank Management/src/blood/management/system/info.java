
package blood.management.system;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class info extends JFrame
{
   info()
   {
        setSize(1000,700);
        setLocation(250,20);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/info.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 700, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 1000, 700);
        add(image);
        
        setVisible(true);
   }
   
   public static void main(String[] args) {
        new info();
    }
}
