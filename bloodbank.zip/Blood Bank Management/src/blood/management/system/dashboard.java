package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class dashboard extends JFrame implements ActionListener
{
     JButton adddonar, addpatient,addcamp,bloodstock,istock,dstock;
      String userType;      
            
    dashboard(String userType)
    {
       this.userType=userType;
       setBounds(0, 0, 1600, 1000);
       setLayout(null);
       
       JPanel p1 = new JPanel();
       p1.setLayout(null);
       p1.setBackground(Color.PINK);
       p1.setBounds(0, 0, 1600,65);
       add(p1);
       
       JLabel heading = new JLabel("Admin Panel");
       heading.setBounds(50,10,300,40);
       heading.setForeground(Color.BLACK);
       heading.setFont(new Font("Tahoma", Font.BOLD, 30));
       p1.add(heading);
       
       ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/logout.png"));
       Image i5 = i4.getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT);
       ImageIcon i6 = new ImageIcon(i5);
       JLabel image1 = new JLabel(i6);
       image1.setBounds(1250,0, 60, 60);
       p1.add(image1);
       
       image1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setVisible(false);

            }
       });
               
       JPanel p2 = new JPanel();
       p2.setLayout(null);
       p2.setBackground(Color.PINK);
       p2.setBounds(0, 65, 300,900);
       add(p2);
       
       ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("icons/viewcamp.png"));
       Image i8 = i7.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
       //adddonar = new JButton("<html><div style='text-align: left;'>Donar List <img src='" + ClassLoader.getSystemResource("icons/donarlist.png") + "' width='50' height='50'></div></html>");

       adddonar = new JButton(" Donor List", new ImageIcon(i8));
       adddonar.setBounds(0, 10, 220, 50);
       adddonar.setBackground(Color.pink);
       adddonar.setForeground(Color.BLACK);
       adddonar.setFont(new Font("Tahoma", Font.PLAIN, 24));
       adddonar.setFocusable(false);
       adddonar.setBorder(BorderFactory.createEmptyBorder());
       //adddonar.setMargin(new Insets(0,10,0,300));
       adddonar.addActionListener(this);
       p2.add(adddonar);
       
       ImageIcon i9 = new ImageIcon(ClassLoader.getSystemResource("icons/addd.png"));
       Image i10 = i9.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
       addpatient = new JButton(" Patient List", new ImageIcon(i10));
       addpatient.setBounds(0, 60, 220, 50);
       addpatient.setBackground(Color.pink);
       addpatient.setForeground(Color.BLACK);
       addpatient.setFont(new Font("Tahoma", Font.PLAIN, 24));
       addpatient.setMargin(new Insets(0,0,0,200));
       addpatient.setFocusable(false);
       addpatient.setBorder(BorderFactory.createEmptyBorder());
       addpatient.addActionListener(this);
       p2.add(addpatient);
       
       ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icons/addcamp.png"));
       Image i12 = i11.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT);
       addcamp = new JButton(" Add Camp", new ImageIcon(i12));
       addcamp.setBounds(0, 110, 210, 50);
       addcamp.setBackground(Color.pink);
       addcamp.setForeground(Color.BLACK);
       addcamp.setFont(new Font("Tahoma", Font.PLAIN, 24));
       addcamp.setMargin(new Insets(0,0,0,200));
       addcamp.setBorder(BorderFactory.createEmptyBorder());
       addcamp.setFocusable(false);
       addcamp.addActionListener(this);
       p2.add(addcamp);
       
       ImageIcon i13 = new ImageIcon(ClassLoader.getSystemResource("icons/bloodbag.png"));
       Image i14 = i13.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
       bloodstock = new JButton(" Blood Stock", new ImageIcon(i14));
       bloodstock.setBounds(5, 160, 210, 50);
       bloodstock.setBackground(Color.pink);
       bloodstock.setForeground(Color.BLACK);
       bloodstock.setFont(new Font("Tahoma", Font.PLAIN, 24));
       bloodstock.setMargin(new Insets(0,0,0,200));
       bloodstock.setBorder(BorderFactory.createEmptyBorder());
       bloodstock.setFocusable(false);
       bloodstock.addActionListener(this);
       p2.add(bloodstock);
       
       
       ImageIcon i15 = new ImageIcon(ClassLoader.getSystemResource("icons/blood.png"));
       Image i16 = i15.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT);
       istock = new JButton(" Increase Stock", new ImageIcon(i16));
       istock.setBounds(5, 210, 250, 50);
       istock.setBackground(Color.pink);
       istock.setForeground(Color.BLACK);
       istock.setFont(new Font("Tahoma", Font.PLAIN, 24));
       //istock.setMargin(new Insets(0,0,0,200));
       istock.setBorder(BorderFactory.createEmptyBorder());
       istock.setFocusable(false);
       istock.addActionListener(this);
       p2.add(istock);
       
       ImageIcon i17 = new ImageIcon(ClassLoader.getSystemResource("icons/blood.png"));
       Image i18 = i17.getImage().getScaledInstance(35, 35, Image.SCALE_DEFAULT);
       dstock = new JButton(" Desrease Stock", new ImageIcon(i18));
       dstock.setBounds(5, 260, 250, 50);
       dstock.setBackground(Color.pink);
       dstock.setForeground(Color.BLACK);
       dstock.setFont(new Font("Tahoma", Font.PLAIN, 24));
      // dstock.setMargin(new Insets(0,0,0,200));
       dstock.setBorder(BorderFactory.createEmptyBorder());
       dstock.setFocusable(false);
       dstock.addActionListener(this);
       p2.add(dstock);
       
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/dashboard.jpeg"));
       Image i2 = i1.getImage().getScaledInstance(1200, 640, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(200,60, 1200, 640);
       add(image);
       
       
       setVisible(true);
    }

    dashboard() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void actionPerformed(ActionEvent ac)
    {
        if (ac.getSource() == adddonar){
            new donardetails();
        } else if(ac.getSource() == addpatient){
            new viewpatient();
        }else if(ac.getSource() == addcamp){
            new addCamp();
        }else if(ac.getSource() == bloodstock){
            new blooddonardetails();
        }else if(ac.getSource() == istock){
            new Increase();
        }else if(ac.getSource() == dstock){
            new decrease();
        }
    }
    
    
    public static void main(String[] args)
    {
        new dashboard("");
    }
}