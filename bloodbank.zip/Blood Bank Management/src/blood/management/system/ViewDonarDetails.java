
package blood.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import java.sql.ResultSet;



public class ViewDonarDetails extends JFrame implements ActionListener
{
    JLabel tfname, tffname, tfmname, tfphone, tfemail, tfcity, tfaddress,  tfgender, tfblood, tflabeldoc,tfquantity
    , labeldonar;
    JTextField tfdonar;
    JButton cancel, search;

    ViewDonarDetails(String donar) 
    {
        setSize(900, 600);
        setLocation(300, 100);
        setLayout(null);

        JLabel heading = new JLabel("VIEW DONOR DETAILS");
        heading.setBounds(310, 20, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 30));
        add(heading);

        JLabel donar1 = new JLabel("Donor ID :");
        donar1.setBounds(200, 80, 150, 30);
        donar1.setFont(new Font("Monospaced", Font.BOLD, 20));
        add(donar1);

        tfdonar = new JTextField();
        tfdonar.setBounds(300, 80, 150, 30);
        add(tfdonar);

        JLabel name = new JLabel("Full Name");
        name.setBounds(50, 150, 100, 30);
        name.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(name);

        tfname = new JLabel();
        tfname.setBounds(200, 150, 180, 30);
        tfname.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfname);

        JLabel fname = new JLabel("Father's Name");
        fname.setBounds(50, 200, 150, 30);
        fname.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(fname);

        tffname = new JLabel();
        tffname.setBounds(200, 200, 180, 30);
        tffname.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tffname);

        JLabel mname = new JLabel("Mother's Name");
        mname.setBounds(50, 250, 150, 30);
        mname.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(mname);

        tfmname = new JLabel();
        tfmname.setBounds(200, 250, 180, 30);
        tfmname.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfmname);

        JLabel dob = new JLabel("Date of Birth");
        dob.setBounds(50, 300, 200, 30);
        dob.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(dob);

        tflabeldoc = new JLabel();
        tflabeldoc.setBounds(200, 300, 180, 30);
        tflabeldoc.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tflabeldoc);

        JLabel phone = new JLabel("Mobile Number");
        phone.setBounds(50, 350, 150, 30);
        phone.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(phone);

        tfphone = new JLabel();
        tfphone.setBounds(200, 350, 180, 30);
        tfphone.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfphone);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(50, 400, 150, 30);
        gender.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(gender);

        tfgender = new JLabel();
        tfgender.setBounds(200, 400, 180, 30);
        tfgender.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfgender);

        JLabel email = new JLabel("Email");
        email.setBounds(450, 150, 200, 30);
        email.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(email);

        tfemail = new JLabel();
        tfemail.setBounds(630, 150, 180, 30);
        tfemail.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfemail);

        JLabel lblcourse = new JLabel("Blood Group");
        lblcourse.setBounds(450, 200, 200, 30);
        lblcourse.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(lblcourse);

        tfblood = new JLabel();
        tfblood.setBounds(630, 200, 180, 30);
         tfblood.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfblood);

        JLabel city = new JLabel("City");
        city.setBounds(450, 250, 200, 30);
        city.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(city);

        tfcity = new JLabel();
        tfcity.setBounds(630, 250, 180, 30);
         tfcity.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfcity);

        JLabel address = new JLabel("Complete Address");
        address.setBounds(450, 300, 200, 30);
        address.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(address);

        tfaddress = new JLabel();
        tfaddress.setBounds(650, 250, 180, 130);
        tfaddress.setFont(new Font("Monospaced", Font.BOLD, 13));
        add(tfaddress);
        
        JLabel units = new JLabel("Enter Quantity");
        units.setBounds(450, 370, 200, 30);
        units.setFont(new Font("TimesRoman ", Font.BOLD, 20));
        add(units);

        tfquantity = new JLabel();
        tfquantity.setBounds(650, 320, 180, 130);
         tfquantity.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(tfquantity);

       

        cancel = new JButton("Cancel");
        cancel.setBounds(400, 480, 100, 30);
        cancel.setBackground(Color.LIGHT_GRAY);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(cancel);

        search = new JButton("Search");
        search.setBounds(550, 80, 100, 30);
        search.setBackground(Color.LIGHT_GRAY);
        search.setForeground(Color.black);
        search.addActionListener(this);
        search.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(search);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 600);
        add(image);

        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) 
    {
        
       if (ae.getSource() == search){
           
           try {
                String query = "select * from details where donar = '"+tfdonar.getText()+"'";
                Conn c = new Conn();
                
                 ResultSet rs = c.s.executeQuery(query);
                 if(rs.next()){
                       tfname.setText(rs.getString("name"));
                        tffname.setText(rs.getString("fname"));
                        tfmname.setText(rs.getString("mname"));
                        tflabeldoc.setText(rs.getString("dob"));
                        tfgender.setText(rs.getString("gender"));
                        tfblood.setText(rs.getString("blood"));
                        tfemail.setText(rs.getString("email"));
                        tfphone.setText(rs.getString("phone"));
                        tfcity.setText(rs.getString("city"));
                        tfaddress.setText(rs.getString("address"));
                        tfquantity.setText(rs.getString("units"));
                    
                 }
                 else{
                      JOptionPane.showMessageDialog(this, "Donor not found");
               
                 }
            } catch(Exception e){
                e.printStackTrace();
            }
       
        
        }  else {
            setVisible(false);

        }
    }
    public static void main(String[] args){
        new  ViewDonarDetails("");
    }
}
