
package blood.management.system;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Locale;

public class Starting extends JFrame implements ActionListener 
{
    JFrame f;
    JLabel l1,l2,l3;
    JButton b1; 
    
    Starting()
    {
      f=new JFrame("Stating Page");
      f.setBackground(Color.WHITE);
      f.setLayout(null);
      
      l1=new JLabel();
      l1.setBounds(0,0,900,570);
      l1.setLayout(null);
      
      ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/start1.jpeg"));
    Image i5 = i4.getImage().getScaledInstance(900, 570, Image.SCALE_DEFAULT);
    ImageIcon i6 = new ImageIcon(i5);
    JLabel image2 = new JLabel(i6);
    image2.setBounds(0,0, 900, 570);
    f.add(image2);
    
     ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
    Image i2 = i1.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
    ImageIcon i3 = new ImageIcon(i2);
    JLabel image = new JLabel(i3);
    image.setBounds(290,0, 300, 250);
    image2.add(image);
      
        
        
        
       l2=new JLabel("Be the Reason of Someone's Heartbeat");
       l2.setBounds(200,200,600,40);
       l2.setFont(new Font("Serif",Font.ITALIC,35));
       l2.setForeground(Color.BLACK);
       l1.add(l2);
       image2.add(l1);
       
       b1=new JButton("Contiue");
       b1.setBounds(350,350,150,40);
       b1.setBackground(Color.PINK);
       b1.setForeground(Color.WHITE);
       l1.add(b1);
      
      b1.addActionListener(this);
      f.setSize(900,570);
      f.setLocation(300,100);
      f.setVisible(true);
      f.setResizable(false);
      
    }
    public void actionPerformed(ActionEvent ac)
    {
    
            if(ac.getSource()==b1)
            {
               this.setVisible(false);
               new Login();
            }
    }
    public static void main(String args[]) 
    {
        new Starting();
    }
}

