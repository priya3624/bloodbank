package blood.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.*;
import java.util.*;
import java.sql.SQLException;

public class Login extends JFrame implements ActionListener 
{
    
    JTextField tfusername,tfname;
    JPasswordField tfpassword;
    JComboBox accountype;
    JButton login, signup;
    
    
    Login()
    {
        setSize(1000,600);
        setLocation(300,100);
        setLayout(null);
        
        JLabel laccount = new JLabel("Login Account as");
        laccount.setBounds(400, 250, 200, 30);
        laccount.setFont(new Font("serif", Font.BOLD, 20));
        add(laccount);
        
        String account[] = {"Admin", "Donar", "Patient"};
        accountype = new JComboBox(account);
        accountype.setBounds(600, 250, 250, 40);
        accountype.setBackground(Color.white);
        add(accountype);
        
        JLabel username = new JLabel("UserName");
        username.setBounds(400,150,350,30);
        username.setFont(new Font("serif", Font.BOLD, 20));
        add(username);
        
        tfusername = new JTextField();
        tfusername.setBounds(600,150,250,30);
        add(tfusername);
        
        JLabel password = new JLabel("Password");
        password.setBounds(400,200,150,30);
        password.setFont(new Font("serif", Font.BOLD, 20));
        add(password);
        
        tfpassword = new JPasswordField();
        tfpassword.setBounds(600,200,250,30);
        add(tfpassword);
        
        login = new JButton("Login");
        login.setBounds(450,350,110,40);
        login.setBackground(Color.PINK);
        login.setForeground(Color.black);
        login.addActionListener(this);
        login.setFont(new Font("Tahome", Font.BOLD, 15));
        add(login);
        
     
        signup = new JButton("Signup");
        signup.setBounds(700,350,110,40);
        signup.setBackground(Color.PINK);
        signup.setForeground(Color.black);
        signup.addActionListener(this);
        signup.setFont(new Font("Tahome", Font.BOLD, 15));
        add(signup);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 1000, 600);
        add(image);
        
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae) { 
    if (ae.getSource() == login) {
        String type = (String) accountype.getSelectedItem();
        String username = tfusername.getText();
        String password = tfpassword.getText();

        try {
            String query = "SELECT * FROM Signup WHERE type = '" + type + "' AND username = '" + username + "' AND password = '" + password + "'";

            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery(query);

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Login Successfully");
                String userType = rs.getString("type"); // Retrieve the user type from the result set
                switch (userType) {
                    case "Donar":
                        new dashboarddonar(userType).setVisible(true); 
                        break;
                    case "Patient":
                        new dashboardpatient(userType).setVisible(true); 
                        break;
                    case "Admin":
                        new dashboard(userType).setVisible(true); 
                        break;
                    default:
                        System.out.println("Invalid user type!");
                        break;
                }
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect username or password. Please try again.");
            }        
        } catch (Exception e) {
            e.printStackTrace();
        }
    } else if (ae.getSource() == signup) {
        setVisible(false);
        new Registration();
    } else {
        setVisible(false);
    }     
}

    
    
    
    public static void main(String args[]) 
    {
       new Login();
       
   }
}    