package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class dashboarddonar extends JFrame implements ActionListener
{
    JButton donar,update,camp,info;
     String userType;  
     
    dashboarddonar(String userType)
    {
       setBounds(0, 0, 1600, 1000);
       setLayout(null);
       
       JPanel p1 = new JPanel();
       p1.setLayout(null);
       p1.setBackground(Color.PINK);
       p1.setBounds(0, 0, 1600,65);
       add(p1);
       
       JLabel heading = new JLabel("Donor Panel");
       heading.setBounds(50,10,300,40);
       heading.setForeground(Color.BLACK);
       heading.setFont(new Font("Tahoma", Font.BOLD, 30));
       p1.add(heading);
       
       JPanel p2 = new JPanel();
       p2.setLayout(null);
       p2.setBackground(Color.PINK);
       p2.setBounds(0, 65, 300,900);
       add(p2);
       
       ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/logout.png"));
       Image i5 = i4.getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT);
       ImageIcon i6 = new ImageIcon(i5);
       JLabel image1 = new JLabel(i6);
       image1.setBounds(1250,0, 60, 60);
       p1.add(image1);
       
       image1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setVisible(false);

            }
       });
       
       ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("icons/adde.png"));
       Image i8 = i7.getImage().getScaledInstance(28, 28, Image.SCALE_DEFAULT);
       donar = new JButton(" Add Donor", new ImageIcon(i8));
       donar.setBounds(0, 10, 220, 50);
       donar.setBackground(Color.pink);
       donar.setForeground(Color.BLACK);
       donar.addActionListener(this);
       donar.setFont(new Font("Tahoma", Font.PLAIN, 24));
      // adddonar.setFocusPainted(false);
       donar.setBorder(BorderFactory.createEmptyBorder());
       donar.setMargin(new Insets(0,0,0,200));
       p2.add(donar);
       
       ImageIcon i9 = new ImageIcon(ClassLoader.getSystemResource("icons/update.png"));
       Image i10 = i9.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
       update = new JButton(" Update Donor Info", new ImageIcon(i10));
       update.setBounds(0, 50, 300, 50);
       update.setBackground(Color.pink);
       update.setForeground(Color.BLACK);
       update.addActionListener(this);
       update.setFont(new Font("Tahoma", Font.PLAIN, 24));
       update.setMargin(new Insets(0,0,0,30));
       update.setBorder(BorderFactory.createEmptyBorder());
       p2.add(update);
       
       ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icons/viewcamp.png"));
       Image i12 = i11.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
       camp = new JButton(" View Camp Details", new ImageIcon(i12));
       camp.setBounds(0, 100, 300, 50);
       camp.setBackground(Color.pink);
       camp.setForeground(Color.BLACK);
       camp.addActionListener(this);
       camp.setFont(new Font("Tahoma", Font.PLAIN, 24));
       camp.setMargin(new Insets(0,0,0,130));
       camp.setBorder(BorderFactory.createEmptyBorder());
       p2.add(camp);
       
       ImageIcon i13 = new ImageIcon(ClassLoader.getSystemResource("icons/info.png"));
       Image i14 = i13.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
       info = new JButton(" Why Donate Blood", new ImageIcon(i14));
       info.setBounds(0, 150, 300, 50);
       info.setBackground(Color.pink);
       info.setForeground(Color.BLACK);
       info.addActionListener(this);
       info.setFont(new Font("Tahoma", Font.PLAIN, 24));
       info.setMargin(new Insets(0,0,0,130));
       info.setBorder(BorderFactory.createEmptyBorder());
       p2.add(info);
       
      
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/p.jpeg"));
       Image i2 = i1.getImage().getScaledInstance(1200, 800, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(200,0, 1200, 800);
       add(image);
       
     
       setVisible(true);
    }
    
   
    
    public void actionPerformed(ActionEvent ac)
    {
        if (ac.getSource() == donar){
            new adddonar();
        } else if(ac.getSource() == update){
            new updatedonar(" ");
        }else if(ac.getSource() == camp){
            new viewcamp();
        }else if(ac.getSource() == info){
            new info();
        }
    }
    
    
    public static void main(String[] args)
    {
        new dashboarddonar("");
    }
}