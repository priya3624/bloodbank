
package blood.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;
 
public class viewcamp extends JFrame implements ActionListener 
{

    JTextField tflocation;
    JTable table;
    JButton search, print,cancel;
    JLabel labelcity;

    viewcamp() 
    {

        JLabel heading = new JLabel("SERACH A NEARBY BLOOD CAMP");
        heading.setBounds(120, 10, 700, 50);
        heading.setFont(new Font("serif", Font.BOLD, 35));
        add(heading);

        JLabel city = new JLabel("LOCATION :");
        city.setBounds(300, 80, 150, 30);
        city.setFont(new Font("Monospaced", Font.BOLD, 20));
        add(city);

        tflocation = new JTextField();
        tflocation.setBounds(400, 80, 150, 30);
        add(tflocation);

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        table = new JTable();

        try {

            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from camp");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 120, 900, 350);
        add(jsp);

        search = new JButton("Serach");
        search.setBounds(600, 80, 100, 30);
        //print.setBackground(Color.LIGHT_GRAY);
        search.setForeground(Color.black);
        search.addActionListener(this);
        search.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(search);

        print = new JButton("Print");
        print.setBounds(100, 500, 100, 30);
        //print.setBackground(Color.LIGHT_GRAY);
        print.setForeground(Color.black);
        print.addActionListener(this);
        print.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(print);
        
        cancel = new JButton("Cancel");
        cancel.setBounds(700, 500, 100, 30);
        //cancel.setBackground(Color.LIGHT_GRAY);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 900, 600);
        add(image);

        setSize(900, 600);
        setLocation(300, 100);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) 
    {
        if (ae.getSource() == search) {

            String query = "select * from camp where location ='" + tflocation.getText() + "'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if(ae.getSource() == print) {
                
                 try{
                     table.print();
                     
                 } catch(Exception e) {
                     e.printStackTrace();
                     
                 }
            } else {
                setVisible(false);
            }
    }  
   
    public static void main(String[] args) {
        new viewcamp();
    }
}

