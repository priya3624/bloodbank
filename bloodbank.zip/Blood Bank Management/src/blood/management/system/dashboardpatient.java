package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class dashboardpatient extends JFrame implements ActionListener
{
    JButton city,bloodgroup,request;
    String userType;
    dashboardpatient(String userType)
    {
       setBounds(0, 0, 1600, 1000);
       setLayout(null);
       
       JPanel p1 = new JPanel();
       p1.setLayout(null);
       p1.setBackground(Color.PINK);
       p1.setBounds(0, 0, 1600,65);
       add(p1);
       
       JLabel heading = new JLabel("Patient Panel");
       heading.setBounds(50,10,300,40);
       heading.setForeground(Color.BLACK);
       heading.setFont(new Font("Tahoma", Font.BOLD, 30));
       p1.add(heading);
       
       ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/logout.png"));
       Image i5 = i4.getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT);
       ImageIcon i6 = new ImageIcon(i5);
       JLabel image1 = new JLabel(i6);
       image1.setBounds(1250,0, 60, 60);
       p1.add(image1);
       
       image1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setVisible(false);

            }
       });
       
       JPanel p2 = new JPanel();
       p2.setLayout(null);
       p2.setBackground(Color.PINK);
       p2.setBounds(0, 65, 300,900);
       add(p2);
       
       ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("icons/loactionserach.png"));
       Image i8 = i7.getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT);
       city = new JButton("Search by Loaction", new ImageIcon(i8));
       city.setBounds(0, 0, 250, 50);
       city.setBackground(Color.pink);
       city.setForeground(Color.BLACK);
       city.setFont(new Font("Tahoma", Font.PLAIN, 24));
      // adddonar.setFocusPainted(false);
       city.setBorder(BorderFactory.createEmptyBorder());
       city.addActionListener(this);
       city.setMargin(new Insets(0,0,0,60));
       p2.add(city);
       
       ImageIcon i9 = new ImageIcon(ClassLoader.getSystemResource("icons/bloodgroupsercch.png"));
       Image i10 = i9.getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT);
       bloodgroup = new JButton("Search by Blood Group", new ImageIcon(i10));
       bloodgroup.setBounds(0, 50, 300, 50);
       bloodgroup.setBackground(Color.pink);
       bloodgroup.setForeground(Color.BLACK);
       bloodgroup.setFont(new Font("Tahoma", Font.PLAIN, 24));
       bloodgroup.setMargin(new Insets(0,0,0,30));
       bloodgroup.addActionListener(this);
       bloodgroup.setBorder(BorderFactory.createEmptyBorder());
       p2.add(bloodgroup);
       
       ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("icons/request.png"));
       Image i12 = i11.getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT);
       request = new JButton("Request for Blood", new ImageIcon(i12));
       request.setBounds(0, 100, 250, 50);
       request.setBackground(Color.pink);
       request.setForeground(Color.BLACK);
       request.setFont(new Font("Tahoma", Font.PLAIN, 24));
       request.setMargin(new Insets(0,0,0,130));
       request.addActionListener(this);
       request.setBorder(BorderFactory.createEmptyBorder());
       p2.add(request);
       
     
      
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/ss.jpg"));
       Image i2 = i1.getImage().getScaledInstance(1300, 640, Image.SCALE_DEFAULT);
       ImageIcon i3 = new ImageIcon(i2);
       JLabel image = new JLabel(i3);
       image.setBounds(200,60, 1300, 640);
       add(image);
       
     
       setVisible(true);
    }
    
    
    
    public void actionPerformed(ActionEvent ac)
    {
        if (ac.getSource() == city){
            new loaction();
        } else if(ac.getSource() == bloodgroup){
            new Bloodgroup();
        }else if(ac.getSource() == request){
            new requestblood();
        }//else if(ac.getSource() == info){
          //  new blooddonardetails();
       // }
    }
    
    
    public static void main(String[] args)
    {
        new dashboardpatient("");
    }
}





