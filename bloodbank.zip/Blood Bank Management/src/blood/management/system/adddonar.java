
package blood.management.system;
                            
import java.util.regex.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class adddonar extends JFrame implements ActionListener 
{
    
    JTextField tfname, tffname,tflast,tfphone,tfemail,tfcity,tfaddress,tfquantity;
    JLabel labeldonar;
    JDateChooser dcdob;
    JComboBox cgender,cblood;
    JButton save, cancel;
    
    Random ran = new Random();
    long first2 = Math.abs((ran.nextLong() % 90L) + 10L);
    
    adddonar() 
    {
        setSize(900,600);
        setLocation(300,100);
        setLayout(null);
        
        JLabel heading = new JLabel("ADD NEW DONOR");
        heading.setBounds(310, 30, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 30));
        add(heading);
        
        JLabel donar = new JLabel("Donor ID");
        donar.setBounds(50,100,180,30);
        donar.setFont(new Font("serif",Font.BOLD,20));
        add(donar);
        
        labeldonar = new JLabel("0"+first2);
        labeldonar.setBounds(200,100,180,30);
        labeldonar.setFont(new Font("serif",Font.BOLD, 20 ));
        add(labeldonar);
        
        JLabel name = new JLabel("Full Name");
        name.setBounds(50, 150, 100, 30);
        name.setFont(new Font("serif", Font.BOLD, 20));
        add(name);
        
        tfname = new JTextField();
        tfname.setBounds(200, 150, 180, 30);
        add(tfname);
        
        JLabel fname = new JLabel("Father's Name");
        fname.setBounds(50, 200, 150, 30);
        fname.setFont(new Font("serif", Font.BOLD, 20));
        add(fname);
        
        tffname = new JTextField();
        tffname.setBounds(200, 200, 180, 30);
        add(tffname);
        
        JLabel last = new JLabel("Last Donated");
        last.setBounds(50, 250, 150, 30);
        last.setFont(new Font("serif", Font.BOLD, 20));
        add(last);
        
        tflast = new JTextField();
        tflast.setBounds(200, 250, 180, 30);
        add(tflast);
        
        JLabel lbldob = new JLabel("Date of Birth");
        lbldob.setBounds(50, 300, 200, 30);
        lbldob.setFont(new Font("serif", Font.BOLD, 20));
        add(lbldob);
        
        dcdob = new JDateChooser();
        dcdob.setBounds(200, 300, 180, 30);
        add(dcdob);
        
        JLabel phone = new JLabel("Mobile Number");
        phone.setBounds(50, 350, 150, 30);
        phone.setFont(new Font("serif", Font.BOLD, 20));
        add(phone);
        
        tfphone = new JTextField();
        tfphone.setBounds(200, 350, 180, 30);
        add(tfphone);
        
        JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(50, 400,150, 30);
        lblgender.setFont(new Font("serif", Font.BOLD, 20));
        add(lblgender);
        
        String gender[] = {"Male", "Female", "Others"};
        cgender = new JComboBox(gender);
        cgender.setBounds(200, 400, 180, 30);
        cgender.setBackground(Color.white);
        add(cgender);
        
        JLabel email = new JLabel("Email");
        email.setBounds(450, 150, 200, 30);
        email.setFont(new Font("serif", Font.BOLD, 20));
        add(email);
        
        tfemail = new JTextField();
        tfemail.setBounds(600, 150, 180, 30);
        add(tfemail);
        
        JLabel lblcourse = new JLabel("Blood Group");
        lblcourse.setBounds(450, 200, 200, 30);
        lblcourse.setFont(new Font("serif", Font.BOLD, 20));
        add(lblcourse);
        
        String blood[] = {"A+", "A-", "B+", "B-", "AB+","AB-", "O+", "O-"};
        cblood = new JComboBox(blood);
        cblood.setBounds(600, 200, 180, 30);
        cblood.setBackground(Color.white);
        add(cblood);
        
        JLabel city = new JLabel("City");
        city.setBounds(450, 250, 200, 30);
        city.setFont(new Font("serif", Font.BOLD, 20));
        add(city);
        
        tfcity = new JTextField();
        tfcity.setBounds(600, 250, 180, 30);
        add(tfcity);
        
        JLabel address = new JLabel("Complete Address");
        address.setBounds(450, 300, 200, 30);
        address.setFont(new Font("serif", Font.BOLD, 20));
        add(address);
        
        tfaddress = new JTextField();
        tfaddress.setBounds(610, 300, 180, 50);
        add(tfaddress);
        
        JLabel units = new JLabel("Enter Quantity");
        units.setBounds(450, 370, 200, 30);
        units.setFont(new Font("serif", Font.BOLD, 20));
        add(units);
        
        tfquantity = new JTextField();
        tfquantity.setBounds(610, 370, 180, 50);
        add(tfquantity);
        
        save = new JButton("Save");
        save.setBounds(250, 480, 150, 30);
        save.setBackground(Color.white);
        save.setForeground(Color.black);
        save.addActionListener(this);
        save.setFont(new Font("Tahome", Font.BOLD, 15));
        add(save);
        
     
        cancel = new JButton("Cancel");
        cancel.setBounds(550, 480, 150, 30);
        cancel.setBackground(Color.white);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Tahome", Font.BOLD, 15));
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 900, 600);
        add(image);
      
        
        setVisible(true);
        
    }
        
         public void actionPerformed(ActionEvent ac) {
         
         if(ac.getSource() == save) 
         {
           String donar = labeldonar.getText();
           String name = tfname.getText();
           String fname = tffname.getText();
           String mname = tflast.getText();
           String dob = ((JTextField) dcdob.getDateEditor().getUiComponent()).getText();
           String address = tfaddress.getText();
           String phone = tfphone.getText();
           String email = tfemail.getText();
           String city = tfcity.getText();
           String units = tfquantity.getText();
           String blood = (String) cblood.getSelectedItem();
           String gender = (String) cgender.getSelectedItem();
           
             if (tfname.getText().trim().isEmpty() || tffname.getText().trim().isEmpty() || tflast.getText().trim().isEmpty() || tfaddress.getText().trim().isEmpty()
                     || tfcity.getText().trim().isEmpty() || tfemail.getText().trim().isEmpty() || tfquantity.getText().trim().isEmpty() || tfphone.getText().trim().isEmpty()) {
                 JOptionPane.showMessageDialog(null, "Please fill in all the details.");
             } else if (!isValidName(tfname.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid Full Name.");
             } else if (!isValidName(tffname.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid father Name.");
             
             } else if (!isValidName(tfaddress.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid address.");
             } else if (!isValidPhoneNumber(tfphone.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter Phone Number.");
             }  else if (!isValidEmail(tfemail.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid email.");
             } else if (!isValidNumber(tfquantity.getText().trim())) {
                 JOptionPane.showMessageDialog(null, "Please enter a valid Quantity");
             }   else {
                 if (!isValidName(name)) {
                    JOptionPane.showMessageDialog(null, "The  name is not valid");
                } else if (!isValidName(fname)) {
                    JOptionPane.showMessageDialog(null, "The father name  is not valid");
                } else if (!isValidPhoneNumber(phone)) {
                     JOptionPane.showMessageDialog(null, "The phone number is not valid");
            } else if (!isValidEmail(email)) {
                     JOptionPane.showMessageDialog(null, "The email is not valid");
            } else if (!isValidName(city)) {
                     JOptionPane.showMessageDialog(null, "The loaction is not valid");
            } else if (!isValidName(address)) {
                     JOptionPane.showMessageDialog(null, "The address is not valid");
            } else if (!isValidNumber(units)) {
                     JOptionPane.showMessageDialog(null, "The units is not valid");
            } else {
             
            
           try {
               String query = "insert into details values('"+donar+"','"+name+"', '"+fname+"', '"+mname+"', '"+dob+"', '"+phone+"', '"+gender+"', '"+email+"', '"+blood+"', '"+city+"', '"+units+"', '"+address+"')";
               
               Conn c = new Conn();
               c.s.executeUpdate(query);
               
               JOptionPane.showMessageDialog(null, "Donor Details Inserted Successfully");
               
               setVisible(false);
           }catch  (Exception e) {
               e.printStackTrace();
            }
            }
           } }else {
             setVisible(false);
         }
         
     } 
         private boolean isValidEmail(String email) 
    {
        String emailRegex = "^[a-z0-9+_.-]+@(.+\\.com)$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
         
     private boolean isValidPhoneNumber(String phone) 
    {
     String phoneRegex = "^[0-9]{10}$";
     return phone.matches(phoneRegex);
    } 
      private boolean isValidName(String name) {
        String NAME_REGEX = "^[a-zA-Z\\s-]+$";
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
      
      private boolean isValidNumber(String number) {
        String NUMBER_REGEX = "^\\d+$"; // Regular expression to match only numbers
        Pattern pattern = Pattern.compile(NUMBER_REGEX);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }
    public static void main(String args[]) 
    {
       new adddonar();
       
   }
}