package blood.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.*;
import java.util.*;
import java.sql.SQLException;
import java.util.regex.*;

public class Registration extends JFrame implements ActionListener {

    JTextField tfusername, tfname;
    JPasswordField tfpassword;
    JComboBox accountype;
    JButton create, back;

    Registration() {
        setSize(1000, 600);
        setLocation(300, 100);
        setLayout(null);

        JLabel laccount = new JLabel("Create Account as");
        laccount.setBounds(50, 100, 200, 30);
        laccount.setFont(new Font("serif", Font.BOLD, 20));
        add(laccount);

        String account[] = {"Admin", "Donar", "Patient"};
        accountype = new JComboBox(account);
        accountype.setBounds(250, 100, 150, 40);
        accountype.setBackground(Color.white);
        add(accountype);

        /*Choice accountype = new Choice();
        accountype.add("Admin");
        accountype.add("Donar");
        accountype.add("Patient");
        accountype.setBounds(250, 100, 150, 40);
        add(accountype);*/
        JLabel name = new JLabel("Full Name");
        name.setBounds(50, 150, 100, 30);
        name.setFont(new Font("serif", Font.BOLD, 20));
        add(name);

        tfname = new JTextField();
        tfname.setBounds(230, 150, 180, 30);
        add(tfname);

        JLabel username = new JLabel("UserName");
        username.setBounds(50, 200, 100, 30);
        username.setFont(new Font("serif", Font.BOLD, 20));
        add(username);

        tfusername = new JTextField();
        tfusername.setBounds(230, 200, 180, 30);
        add(tfusername);

        JLabel password = new JLabel("Password");
        password.setBounds(50, 250, 100, 30);
        password.setFont(new Font("serif", Font.BOLD, 20));
        add(password);

        tfpassword = new JPasswordField();
        tfpassword.setBounds(230, 250, 180, 30);
        add(tfpassword);

        create = new JButton("Create");
        create.setBounds(250, 480, 150, 30);
        create.setBackground(Color.white);
        create.setForeground(Color.black);
        create.addActionListener(this);
        create.setFont(new Font("Tahome", Font.BOLD, 15));
        add(create);

        back = new JButton("Back");
        back.setBounds(550, 480, 150, 30);
        back.setBackground(Color.white);
        back.setForeground(Color.black);
        back.addActionListener(this);
        back.setFont(new Font("Tahome", Font.BOLD, 15));
        add(back);

        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/aa.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1000, 600);
        add(image);
        
        setVisible(true);
    }

    /**
     *
     * @param ae
     */
    public void actionPerformed(ActionEvent ae) 
    {
        if (ae.getSource() == create) 
        {
            String type = (String) accountype.getSelectedItem();
            String name = tfname.getText();
            String username = tfusername.getText();
            String password = tfpassword.getText();

            if (tfname.getText().trim().isEmpty() || tfusername.getText().trim().isEmpty() || tfpassword.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all the details.");
            } else if (tfname.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Full Name.");
            } else if (tfusername.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter UserName.");
            } else if (tfpassword.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Password");
            } else {
                if (!isValidName(name)) {
                    JOptionPane.showMessageDialog(null, "The name is not valid");
                } else if (isValidUsername(username)) {
                    JOptionPane.showMessageDialog(null, "The username is not valid");
                } else if (!isValidPassword(password)) {
                    JOptionPane.showMessageDialog(null, "The password is not valid");
                }else 
                {

                    try 
                    {

                        String query = "Insert into Signup values('" + type + "','" + name + "','" + username + "','" + password + "')";

                        Conn c = new Conn();
                        c.s.executeUpdate(query);

                        JOptionPane.showMessageDialog(null, "Account Created Successfully");

                        setVisible(false);
                        new Login();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            } else if (ae.getSource() == back)
            {
                setVisible(false);

            }
        
      } 
         
         

    private boolean isValidName(String name) {

        return name.matches("^[a-zA-Z\\s]+$");
    }

    private boolean isValidPassword(String password) {

        String passwordRegex = "^[0-9]+$";
        Pattern pattern = Pattern.compile(passwordRegex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

   private static boolean isValidUsername(String username) {
        String usernameRegex = "^[a-zA-Z ]+$";
        Pattern pattern = Pattern.compile(usernameRegex);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
    }

    public static void main(String args[]) {
        new Registration();

    }

}
