package blood.management.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;
import java.awt.event.*;

public class donardetails extends JFrame implements ActionListener {

    JTable table;
    JButton print, cancel;

    donardetails() {
        JLabel heading = new JLabel("DONOR DETAILS");
        heading.setBounds(250, 10, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 40));
        add(heading);

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        table = new JTable();

        try {

            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from details");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 380);
        add(jsp);

        print = new JButton("Print");
        print.setBounds(80, 500, 100, 30);
        //print.setBackground(Color.LIGHT_GRAY);
        print.setForeground(Color.black);
        print.addActionListener(this);
        print.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(print);

        cancel = new JButton("Cancel");
        cancel.setBounds(700, 500, 100, 30);
        //cancel.setBackground(Color.LIGHT_GRAY);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Monospaced", Font.BOLD, 15));
        add(cancel);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 600);
        add(image);

        setSize(900, 600);
        setLocation(300, 100);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == print) {

            try {
                table.print();

            } catch (Exception e) {
                e.printStackTrace();

            }
        } else {
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new donardetails();
    }
}
