package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class decrease extends JFrame implements ActionListener {
    JTable table;
    JTextField tfunits;
    JComboBox<String> cblood; // Specify the type parameter for JComboBox
    JButton decrease, print, cancel;
    DefaultTableModel model;

    decrease() {
        setSize(900, 600);
        setLocation(300, 100);
        setLayout(null);

        JLabel heading = new JLabel("STOCK (INCREASE)");
        heading.setBounds(310, 20, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 30));
        add(heading);

        JLabel lblcourse = new JLabel("Blood Group");
        lblcourse.setBounds(50, 80, 170, 30);
        lblcourse.setFont(new Font("serif", Font.BOLD, 20));
        add(lblcourse);

        String blood[] = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
        cblood = new JComboBox<>(blood); // Specify the type parameter for JComboBox
        cblood.setBounds(170, 80, 120, 30);
        cblood.setBackground(Color.white);
        add(cblood);

        JLabel unit = new JLabel("UNITS");
        unit.setBounds(350, 80, 150, 30);
        unit.setFont(new Font("Monospaced", Font.BOLD, 20));
        add(unit);

        tfunits = new JTextField();
        tfunits.setBounds(420, 80, 120, 30);
        add(tfunits);

        table = new JTable();

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from Blood");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(70, 150, 750, 300);
        add(jsp);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 600);
        add(image);

        decrease = new JButton("Decrease");
        decrease.setBounds(650, 80, 120, 30);
        decrease.setForeground(Color.black);
        decrease.addActionListener(this);
        decrease.setFont(new Font("Monospaced", Font.BOLD, 15));
        image.add(decrease);

        print = new JButton("Print");
        print.setBounds(100, 500, 100, 30);
        print.setForeground(Color.black);
        print.addActionListener(this);
        print.setFont(new Font("Monospaced", Font.BOLD, 15));
        image.add(print);

        cancel = new JButton("Cancel");
        cancel.setBounds(700, 500, 100, 30);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Monospaced", Font.BOLD, 15));
        image.add(cancel);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == decrease) {
            // Get selected blood group and new units value
            String selectedBloodGroup = (String) cblood.getSelectedItem();
            int newUnits = Integer.parseInt(tfunits.getText());

            // Update the table
            updateRow(selectedBloodGroup, newUnits);
        } else if (ae.getSource() == print) {
            try {
                table.print();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    private void updateRow(String bloodGroup, int newUnits) {
        try {
            // Update the database with the new units
            Conn c = new Conn();
            String query = "UPDATE Blood SET units = units - " + newUnits + " WHERE bloodgroup = '" + bloodGroup + "'";
            c.s.executeUpdate(query);

            // Refresh the table to reflect the changes
            ResultSet rs = c.s.executeQuery("SELECT * FROM Blood");
            table.setModel(DbUtils.resultSetToTableModel(rs));

            JOptionPane.showMessageDialog(this, "Units for " + bloodGroup + " Decreased successfully!!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error decreasing units for " + bloodGroup, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new decrease();
    }
}
