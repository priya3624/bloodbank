package blood.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.regex.*;
import javax.swing.ImageIcon;

public class addCamp extends JFrame implements ActionListener {

    JTextField tfdate, tflocation, tftime;
    JButton add, cancel;

    addCamp() {
        setSize(900, 600);
        setLocation(300, 100);
        setLayout(null);

        JLabel heading = new JLabel("ADD CAMP DETAILS");
        heading.setBounds(310, 30, 500, 50);
        heading.setFont(new Font("serif", Font.BOLD, 30));
        add(heading);

        JLabel date = new JLabel("Date");
        date.setBounds(50, 150, 100, 30);
        date.setFont(new Font("serif", Font.BOLD, 20));
        add(date);

        tfdate = new JTextField();
        tfdate.setBounds(200, 150, 180, 30);
        add(tfdate);

        JLabel location = new JLabel("Location"); // Corrected typo in variable name
        location.setBounds(50, 200, 100, 30);
        location.setFont(new Font("serif", Font.BOLD, 20));
        add(location);

        tflocation = new JTextField(); // Corrected variable name
        tflocation.setBounds(200, 200, 180, 30);
        add(tflocation);

        JLabel time = new JLabel("Time");
        time.setBounds(50, 250, 100, 30);
        time.setFont(new Font("serif", Font.BOLD, 20));
        add(time);

        tftime = new JTextField();
        tftime.setBounds(200, 250, 180, 30);
        add(tftime);

        add = new JButton("Save");
        add.setBounds(250, 480, 150, 30);
        add.setBackground(Color.white);
        add.setForeground(Color.black);
        add.addActionListener(this);
        add.setFont(new Font("Tahoma", Font.BOLD, 15)); 
        add(add);

        cancel = new JButton("Cancel");
        cancel.setBounds(550, 480, 150, 30);
        cancel.setBackground(Color.white);
        cancel.setForeground(Color.black);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Tahoma", Font.BOLD, 15)); 
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/addonar.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0, 900, 600);
        add(image);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add)
        {
            String date = tfdate.getText();
            String location = tflocation.getText(); // Corrected variable name
            String time = tftime.getText();
            
            if (tfdate.getText().trim().isEmpty() || tflocation.getText().trim().isEmpty() || tftime.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all the details.");
            } else if (tflocation.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Loaction.");
            } else if (tftime.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Time");
            } else if (tfdate.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter Date");
            } else {
                if (!isValidTime(time)) {
                    JOptionPane.showMessageDialog(null, "The time is not valid");
                } else if (!isValidDate(date)) {
                    JOptionPane.showMessageDialog(null, "The date is not valid");
                } else if (!isValidName(location)) {
                     JOptionPane.showMessageDialog(null, "The loaction is not valid");
            } else {

            try 
            {
                String query = "insert into camp values('" + date + "', '" + location + "','" + time + "')";

                Conn c = new Conn();
                c.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null, "Details Added Successfully");
                setVisible(false);

            } catch (Exception e) {
                e.printStackTrace();
            }
         }   
            }     
        } else if (ae.getSource() == cancel) {
            setVisible(false);
        }
    }
    
    private boolean isValidTime(String time)
    {
        String TIME_REGEX = "^(?:[01]\\d|2[0-3]):[0-5]\\d$";
        Pattern pattern = Pattern.compile(TIME_REGEX);
        Matcher matcher = pattern.matcher(time);
        return matcher.matches();
        
    }
    
    private boolean isValidDate(String date)
    {
       String DATE_REGEX = "^\\d{4}-\\d{2}-\\d{2}$";
       Pattern pattern = Pattern.compile(DATE_REGEX);
        Matcher matcher = pattern.matcher(date);
        return matcher.matches();
    }
    
     private boolean isValidName(String name) {
        String NAME_REGEX = "^[a-zA-Z\\s-]+$";
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
     
      
    
    public static void main(String args[]) {
        new addCamp();
    }
}
